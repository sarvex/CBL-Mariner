pip3 install -r utils/requirements-docs.txt
cd docs
make html
