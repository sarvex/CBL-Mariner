from setuptools import setup

setup(
    name='module_to_install_in_editable_mode',
    packages=[],
)
