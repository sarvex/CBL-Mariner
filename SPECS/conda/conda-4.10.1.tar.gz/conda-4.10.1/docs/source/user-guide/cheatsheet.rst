===========
Cheat sheet
===========

See the :download:`conda cheat sheet <conda-cheatsheet.pdf>` PDF
(1 MB) for a single-page summary of the most important
information about using conda.
