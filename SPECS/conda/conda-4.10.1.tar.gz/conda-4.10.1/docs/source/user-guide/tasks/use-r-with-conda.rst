use-r-with-conda
================

.. raw:: html

        <html><head><meta http-equiv="refresh" content="0; URL='https://docs.anaconda.com/anaconda/user-guide/tasks/use-r-language'" /></head><body></body></html>
