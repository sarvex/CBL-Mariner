=============
Configuration
=============

.. toctree::
   :maxdepth: 1

   use-condarc
   sample-condarc
   free-channel
   admin-multi-user-install
   enable-tab-completion
   pip-interoperability
   use-winxp-with-proxy
   disable-ssl-verification
   non-standard-certs
