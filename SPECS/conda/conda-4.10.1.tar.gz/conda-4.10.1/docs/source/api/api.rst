``conda.api``
==============

.. py:module:: conda.api

.. autoclass:: Solver
   :members:
   :undoc-members:

.. autoclass:: SubdirData
  :members:
  :undoc-members:

.. autoclass:: PackageCacheData
  :members:
  :undoc-members:

.. autoclass:: PrefixData
  :members:
  :undoc-members:
