``conda.api.Solver``
====================

.. py:module:: conda.core.solve

.. autoclass:: DepsModifier
   :members:
   :undoc-members:

.. autoclass:: Solver
   :members:
