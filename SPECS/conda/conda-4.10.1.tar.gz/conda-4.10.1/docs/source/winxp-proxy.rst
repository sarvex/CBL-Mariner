winxp-proxy
===========

.. raw:: html

        <html><head><meta http-equiv="refresh" content="0; URL='user-guide/configuration/use-winxp-with-proxy.html'" /></head><body></body></html>
