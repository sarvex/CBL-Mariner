:orphan:

Redirects
=========

.. raw:: html

        <html><head><meta http-equiv="refresh" content="0; URL='index.html'" /></head><body></body></html>

.. toctree::
   :hidden:

   admin
   changelog
   channels
   config
   custom-channels
   download
   env-commands
   faq
   general-commands
   get-started
   installation
   intro
   mro
   py2or3
   r-with-conda
   test-drive
   travis
   troubleshooting
   winxp-proxy
   help/conda-pip-virtualenv-translator
   help/silent
   install/central
   install/full
   install/quick
   install/sample-condarc
   install/tab-completion
   user-guide/tasks/use-mro-with-conda
   user-guide/tasks/use-r-with-conda
   using/cheatsheet
   using/envs
   using/index
   using/pkgs
   using/test-drive
   using/using
   configuration
   api/index
