using/test-drive
================

.. raw:: html

        <html><head><meta http-equiv="refresh" content="0; URL='../user-guide/getting-started.html'" /></head><body></body></html>
