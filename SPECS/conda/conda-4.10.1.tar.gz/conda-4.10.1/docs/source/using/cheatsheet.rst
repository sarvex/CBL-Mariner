using/cheatsheet
================

.. raw:: html

        <html><head><meta http-equiv="refresh" content="0; URL='../user-guide/cheatsheet.html'" /></head><body></body></html>
