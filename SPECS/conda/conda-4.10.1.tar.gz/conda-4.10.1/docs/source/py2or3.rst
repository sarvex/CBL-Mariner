py2or3
======

.. raw:: html

        <html><head><meta http-equiv="refresh" content="0; URL='user-guide/tasks/manage-python.html'" /></head><body></body></html>
