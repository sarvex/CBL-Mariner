``conda config``
*****************

.. argparse::
   :module: conda.cli.conda_argparse
   :func: generate_parser
   :prog: conda
   :path: config
   :nodefault:
   :nodefaultconst:
