``conda search``
*****************

.. argparse::
   :module: conda.cli.conda_argparse
   :func: generate_parser
   :prog: conda
   :path: search
   :nodefault:
   :nodefaultconst:
