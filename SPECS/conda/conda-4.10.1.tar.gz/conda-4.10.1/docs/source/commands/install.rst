``conda install``
*****************

.. argparse::
   :module: conda.cli.conda_argparse
   :func: generate_parser
   :prog: conda
   :path: install
   :nodefault:
   :nodefaultconst:
