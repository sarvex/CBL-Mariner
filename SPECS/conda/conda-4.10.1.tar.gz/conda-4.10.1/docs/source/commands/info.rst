``conda info``
*****************

.. argparse::
   :module: conda.cli.conda_argparse
   :func: generate_parser
   :prog: conda
   :path: info
   :nodefault:
   :nodefaultconst:
