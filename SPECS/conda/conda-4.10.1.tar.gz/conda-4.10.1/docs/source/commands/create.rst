``conda create``
*****************

.. argparse::
   :module: conda.cli.conda_argparse
   :func: generate_parser
   :prog: conda
   :path: create
   :nodefault:
   :nodefaultconst:
