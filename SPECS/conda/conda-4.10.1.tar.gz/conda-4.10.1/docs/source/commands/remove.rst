``conda remove``
*****************

.. argparse::
   :module: conda.cli.conda_argparse
   :func: generate_parser
   :prog: conda
   :path: remove
   :nodefault:
   :nodefaultconst:
