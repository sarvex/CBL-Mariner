install/sample-condarc
======================

.. raw:: html

        <html><head><meta http-equiv="refresh" content="0; URL='../user-guide/configuration/sample-condarc.html'" /></head><body></body></html>
